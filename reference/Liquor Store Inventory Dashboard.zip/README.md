
  # Liquor Store Inventory Dashboard

  This is a code bundle for Liquor Store Inventory Dashboard. The original project is available at https://www.figma.com/design/DrwHkF16S2f3Abkg6Mz1YF/Liquor-Store-Inventory-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  