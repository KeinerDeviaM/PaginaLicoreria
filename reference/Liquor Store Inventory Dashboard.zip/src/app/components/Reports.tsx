import { motion } from "motion/react";
import { Download, Calendar, Filter, TrendingUp, DollarSign, Package } from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const salesData = [
  { month: "Jan", sales: 45000, purchases: 32000, profit: 13000 },
  { month: "Feb", sales: 52000, purchases: 35000, profit: 17000 },
  { month: "Mar", sales: 48000, purchases: 33000, profit: 15000 },
  { month: "Apr", sales: 61000, purchases: 38000, profit: 23000 },
  { month: "May", sales: 55000, purchases: 36000, profit: 19000 },
  { month: "Jun", sales: 67000, purchases: 41000, profit: 26000 },
];

const topProducts = [
  { name: "Jack Daniel's No. 7", sales: 12500, units: 432 },
  { name: "Château Margaux 2015", sales: 10788, units: 12 },
  { name: "Grey Goose Vodka", sales: 9598, units: 240 },
  { name: "Macallan 18 Year", sales: 8376, units: 24 },
  { name: "Hennessy V.S", sales: 7495, units: 150 },
];

export default function Reports() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Reports</h1>
          <p className="text-muted-foreground">Analytics and performance insights</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
        >
          <Download className="w-5 h-5" />
          Export Report
        </motion.button>
      </div>

      {/* Filters */}
      <div className="bg-surface rounded-xl p-6 border border-gold/10">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm text-muted-foreground mb-2">Date Range</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Select date range"
                className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
              />
            </div>
          </div>
          <div className="flex-1">
            <label className="block text-sm text-muted-foreground mb-2">Category</label>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <select className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all appearance-none">
                <option>All Categories</option>
                <option>Whiskey</option>
                <option>Wine</option>
                <option>Vodka</option>
                <option>Rum</option>
              </select>
            </div>
          </div>
          <div className="flex-1">
            <label className="block text-sm text-muted-foreground mb-2">Report Type</label>
            <select className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all appearance-none">
              <option>Sales Summary</option>
              <option>Inventory Status</option>
              <option>Purchase Orders</option>
              <option>Profit Analysis</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gold/10 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-gold" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">$328,000</div>
              <div className="text-sm text-muted-foreground">Total Sales (6 months)</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">$113,000</div>
              <div className="text-sm text-muted-foreground">Total Profit (6 months)</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-wine/10 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-wine" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">858</div>
              <div className="text-sm text-muted-foreground">Units Sold (6 months)</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Sales & Profit Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-surface rounded-xl p-6 border border-gold/10"
      >
        <h2 className="text-xl font-semibold text-white mb-6">Sales & Profit Overview</h2>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={salesData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(212, 175, 55, 0.1)" />
            <XAxis dataKey="month" stroke="#a3a3a3" key="xaxis-sales" />
            <YAxis stroke="#a3a3a3" key="yaxis-sales" />
            <Tooltip
              key="tooltip-sales"
              contentStyle={{
                backgroundColor: "#141414",
                border: "1px solid rgba(212, 175, 55, 0.2)",
                borderRadius: "8px",
              }}
              labelStyle={{ color: "#ffffff" }}
            />
            <Legend key="legend-sales" />
            <Bar key="bar-sales" dataKey="sales" fill="#D4AF37" name="Sales" radius={[8, 8, 0, 0]} />
            <Bar key="bar-purchases" dataKey="purchases" fill="#722F37" name="Purchases" radius={[8, 8, 0, 0]} />
            <Bar key="bar-profit" dataKey="profit" fill="#8B4513" name="Profit" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Top Products */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-surface rounded-xl p-6 border border-gold/10"
      >
        <h2 className="text-xl font-semibold text-white mb-6">Top Selling Products</h2>
        <div className="space-y-4">
          {topProducts.map((product, index) => (
            <div
              key={product.name}
              className="flex items-center justify-between p-4 bg-surface-elevated rounded-lg border border-gold/5"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                  <span className="text-gold font-semibold">#{index + 1}</span>
                </div>
                <div>
                  <div className="text-white font-medium">{product.name}</div>
                  <div className="text-sm text-muted-foreground">{product.units} units sold</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-semibold text-white">
                  ${product.sales.toLocaleString()}
                </div>
                <div className="text-sm text-green-500">Revenue</div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
