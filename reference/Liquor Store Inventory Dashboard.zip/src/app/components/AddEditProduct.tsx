import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, Save, Image as ImageIcon, X } from "lucide-react";

export default function AddEditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const [formData, setFormData] = useState({
    code: isEditing ? "MAC-25Y-001" : "",
    name: isEditing ? "Macallan 25 Year Old" : "",
    category: isEditing ? "Single Malt Scotch" : "",
    brand: isEditing ? "The Macallan" : "",
    supplier: isEditing ? "Edrington Group" : "",
    price: isEditing ? "1999.00" : "",
    cost: isEditing ? "1200.00" : "",
    stock: isEditing ? "3" : "",
    minStock: isEditing ? "2" : "",
    status: isEditing ? "active" : "draft",
    description: isEditing ? "The Macallan 25 Years Old Sherry Oak is an exquisite single malt scotch whisky." : ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/products");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Link
            to="/products"
            className="w-10 h-10 bg-surface-elevated rounded-lg border border-gold/10 flex items-center justify-center text-muted-foreground hover:text-white hover:border-gold/30 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-white">
              {isEditing ? "Edit Product" : "Add New Product"}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {isEditing ? "Update inventory details and product information." : "Create a new product in the inventory."}
            </p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link
            to="/products"
            className="px-4 py-2 bg-surface-elevated text-white rounded-lg border border-gold/10 font-medium hover:bg-white/5 transition-colors flex items-center gap-2"
          >
            <X className="w-4 h-4" /> Cancel
          </Link>
          <button
            onClick={handleSubmit}
            className="px-6 py-2 bg-gold text-black rounded-lg font-bold shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:bg-white transition-colors flex items-center gap-2"
          >
            <Save className="w-4 h-4" /> {isEditing ? "Save Changes" : "Create Product"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-surface rounded-2xl border border-gold/10 p-6">
            <h2 className="text-lg font-bold text-white mb-6">Basic Information</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Product Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                  placeholder="e.g. Macallan 25 Year Old"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Product Code (SKU)</label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                    placeholder="MAC-25Y-001"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all appearance-none"
                  >
                    <option value="active">Active</option>
                    <option value="draft">Draft</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full h-32 bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all resize-none"
                  placeholder="Enter product description..."
                />
              </div>
            </div>
          </div>

          <div className="bg-surface rounded-2xl border border-gold/10 p-6">
            <h2 className="text-lg font-bold text-white mb-6">Pricing & Inventory</h2>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Selling Price ($)</label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Cost Price ($)</label>
                <input
                  type="number"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Current Stock</label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Minimum Stock Alert</label>
                <input
                  type="number"
                  value={formData.minStock}
                  onChange={(e) => setFormData({ ...formData, minStock: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all"
                  placeholder="0"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Form */}
        <div className="space-y-8">
          <div className="bg-surface rounded-2xl border border-gold/10 p-6">
            <h2 className="text-lg font-bold text-white mb-6">Product Image</h2>
            <div className="border-2 border-dashed border-gold/20 rounded-xl p-8 text-center hover:bg-surface-elevated hover:border-gold/50 transition-all cursor-pointer group">
              <div className="w-16 h-16 bg-gold/5 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <ImageIcon className="w-8 h-8 text-gold/50" />
              </div>
              <h3 className="text-sm font-medium text-white mb-1">Click to upload</h3>
              <p className="text-xs text-muted-foreground">PNG, JPG or WEBP (Max. 5MB)</p>
            </div>
          </div>

          <div className="bg-surface rounded-2xl border border-gold/10 p-6">
            <h2 className="text-lg font-bold text-white mb-6">Organization</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all appearance-none"
                >
                  <option value="">Select category...</option>
                  <option value="Single Malt Scotch">Single Malt Scotch</option>
                  <option value="Champagne">Champagne</option>
                  <option value="Red Wine">Red Wine</option>
                  <option value="Vodka">Vodka</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Brand</label>
                <select
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all appearance-none"
                >
                  <option value="">Select brand...</option>
                  <option value="The Macallan">The Macallan</option>
                  <option value="Dom Pérignon">Dom Pérignon</option>
                  <option value="Grey Goose">Grey Goose</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Supplier</label>
                <select
                  value={formData.supplier}
                  onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all appearance-none"
                >
                  <option value="">Select supplier...</option>
                  <option value="Edrington Group">Edrington Group</option>
                  <option value="Moët Hennessy">Moët Hennessy</option>
                  <option value="Diageo">Diageo</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}