import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Trash2, Minus, Plus, ChevronRight, ShoppingBag } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function Cart() {
  const [items, setItems] = useState([
    {
      id: "1",
      name: "Macallan 25 Year Old",
      brand: "The Macallan",
      price: 1999.0,
      quantity: 1,
      image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80",
    },
    {
      id: "2",
      name: "Dom Pérignon Vintage 2012",
      brand: "Dom Pérignon",
      price: 249.99,
      quantity: 2,
      image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?w=800&q=80",
    },
  ]);

  const updateQuantity = (id: string, newQty: number) => {
    if (newQty < 1) return;
    setItems(items.map((item) => (item.id === id ? { ...item, quantity: newQty } : item)));
  };

  const removeItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const taxes = subtotal * 0.08;
  const shipping = 25.0;
  const total = subtotal + taxes + shipping;

  return (
    <div className="flex-1 bg-[#0a0a0a] min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-12 lg:py-20">
        <h1 className="text-4xl font-bold tracking-tight text-white mb-12">Shopping Cart</h1>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 bg-[#121212] rounded-2xl border border-white/5">
            <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6">
              <ShoppingBag className="w-10 h-10 text-white/20" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Your cart is empty</h2>
            <p className="text-white/50 mb-8">Looks like you haven't added anything yet.</p>
            <Link to="/shop/products" className="px-8 py-4 bg-gold text-black font-bold uppercase tracking-wider text-sm rounded hover:bg-white transition-colors">
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Cart Items */}
            <div className="flex-1">
              <div className="hidden lg:grid grid-cols-12 gap-4 pb-4 border-b border-white/10 text-xs font-bold uppercase tracking-wider text-white/40">
                <div className="col-span-6">Product</div>
                <div className="col-span-2 text-center">Price</div>
                <div className="col-span-2 text-center">Quantity</div>
                <div className="col-span-2 text-right">Total</div>
              </div>

              <div className="divide-y divide-white/10">
                {items.map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="py-8 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-4 items-center"
                  >
                    {/* Product Info */}
                    <div className="col-span-1 lg:col-span-6 flex items-center gap-6">
                      <div className="w-24 h-32 bg-black rounded-lg border border-white/5 flex items-center justify-center p-2 shrink-0">
                        <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-contain" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-gold uppercase tracking-wider mb-1">{item.brand}</div>
                        <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">{item.name}</h3>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-xs text-wine hover:text-white flex items-center gap-1 transition-colors"
                        >
                          <Trash2 className="w-3 h-3" /> Remove
                        </button>
                      </div>
                    </div>

                    {/* Price (Mobile & Desktop) */}
                    <div className="col-span-1 lg:col-span-2 flex justify-between lg:justify-center items-center">
                      <span className="lg:hidden text-sm text-white/50">Price:</span>
                      <span className="text-lg font-medium text-white/80">
                        ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    {/* Quantity */}
                    <div className="col-span-1 lg:col-span-2 flex justify-between lg:justify-center items-center">
                      <span className="lg:hidden text-sm text-white/50">Quantity:</span>
                      <div className="flex items-center bg-[#1a1a1a] border border-white/10 rounded">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-10 text-center text-sm font-bold text-white">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Total */}
                    <div className="col-span-1 lg:col-span-2 flex justify-between lg:justify-end items-center">
                      <span className="lg:hidden text-sm text-white/50">Total:</span>
                      <span className="text-xl font-bold text-white">
                        ${(item.price * item.quantity).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="w-full lg:w-96 shrink-0">
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-8 sticky top-28">
                <h2 className="text-xl font-bold text-white mb-6">Order Summary</h2>
                
                <div className="space-y-4 mb-8">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Subtotal</span>
                    <span className="text-white font-medium">${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Shipping Estimate</span>
                    <span className="text-white font-medium">${shipping.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Tax Estimate (8%)</span>
                    <span className="text-white font-medium">${taxes.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>

                <div className="border-t border-white/10 pt-6 mb-8">
                  <div className="flex justify-between items-end">
                    <span className="text-base font-bold text-white">Total</span>
                    <span className="text-3xl font-bold text-gold">${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>

                <Link
                  to="/shop/checkout"
                  className="w-full bg-gold text-black font-bold uppercase tracking-wider text-sm py-4 rounded flex items-center justify-center gap-2 hover:bg-white transition-colors shadow-[0_0_20px_rgba(212,175,55,0.2)]"
                >
                  Proceed to Checkout <ChevronRight className="w-4 h-4" />
                </Link>

                <div className="mt-6 text-center">
                  <Link to="/shop/products" className="text-xs text-white/50 hover:text-white uppercase tracking-wider transition-colors">
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}