import { motion } from "motion/react";
import { AlertTriangle, AlertCircle, XCircle, Package, TrendingDown } from "lucide-react";

const alerts = [
  {
    id: 1,
    type: "critical",
    product: "Johnnie Walker Blue",
    stock: 0,
    threshold: 10,
    category: "Whiskey",
    message: "Out of stock - Immediate restocking required",
  },
  {
    id: 2,
    type: "warning",
    product: "Château Margaux 2015",
    stock: 8,
    threshold: 15,
    category: "Wine",
    message: "Low stock - Below minimum threshold",
  },
  {
    id: 3,
    type: "warning",
    product: "Grey Goose Vodka",
    stock: 8,
    threshold: 20,
    category: "Vodka",
    message: "Low stock - Reorder recommended",
  },
  {
    id: 4,
    type: "info",
    product: "Macallan 18 Year",
    stock: 12,
    threshold: 15,
    category: "Whiskey",
    message: "Stock approaching minimum threshold",
  },
  {
    id: 5,
    type: "warning",
    product: "Rémy Martin XO",
    stock: 6,
    threshold: 12,
    category: "Cognac",
    message: "Low stock - Below minimum threshold",
  },
  {
    id: 6,
    type: "info",
    product: "Dom Pérignon 2010",
    stock: 14,
    threshold: 18,
    category: "Champagne",
    message: "Stock approaching minimum threshold",
  },
  {
    id: 7,
    type: "critical",
    product: "Pappy Van Winkle 23",
    stock: 2,
    threshold: 8,
    category: "Whiskey",
    message: "Critical low stock - Priority restocking",
  },
];

export default function Alerts() {
  const criticalCount = alerts.filter((a) => a.type === "critical").length;
  const warningCount = alerts.filter((a) => a.type === "warning").length;
  const infoCount = alerts.filter((a) => a.type === "info").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">Stock Alerts</h1>
        <p className="text-muted-foreground">Monitor low stock items and critical alerts</p>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-surface rounded-xl p-6 border border-red-500/20"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-red-500/10 rounded-lg flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <div className="text-3xl font-semibold text-white">{criticalCount}</div>
              <div className="text-sm text-muted-foreground">Critical Alerts</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-surface rounded-xl p-6 border border-yellow-500/20"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <div className="text-3xl font-semibold text-white">{warningCount}</div>
              <div className="text-sm text-muted-foreground">Warnings</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-surface rounded-xl p-6 border border-blue-500/20"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <div className="text-3xl font-semibold text-white">{infoCount}</div>
              <div className="text-sm text-muted-foreground">Info</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {alerts.map((alert, index) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`bg-surface rounded-xl p-6 border ${
              alert.type === "critical"
                ? "border-red-500/20 hover:border-red-500/30"
                : alert.type === "warning"
                ? "border-yellow-500/20 hover:border-yellow-500/30"
                : "border-blue-500/20 hover:border-blue-500/30"
            } transition-all group`}
          >
            <div className="flex items-start gap-4">
              <div
                className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  alert.type === "critical"
                    ? "bg-red-500/10"
                    : alert.type === "warning"
                    ? "bg-yellow-500/10"
                    : "bg-blue-500/10"
                }`}
              >
                {alert.type === "critical" ? (
                  <XCircle className="w-6 h-6 text-red-500" />
                ) : alert.type === "warning" ? (
                  <AlertTriangle className="w-6 h-6 text-yellow-500" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-blue-500" />
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-1">{alert.product}</h3>
                    <p
                      className={`text-sm font-medium ${
                        alert.type === "critical"
                          ? "text-red-500"
                          : alert.type === "warning"
                          ? "text-yellow-500"
                          : "text-blue-500"
                      }`}
                    >
                      {alert.message}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      alert.type === "critical"
                        ? "bg-red-500/10 text-red-500"
                        : alert.type === "warning"
                        ? "bg-yellow-500/10 text-yellow-500"
                        : "bg-blue-500/10 text-blue-500"
                    }`}
                  >
                    {alert.type.toUpperCase()}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4 mt-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Category</div>
                    <div className="text-white font-medium">{alert.category}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Current Stock</div>
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-gold" />
                      <span className="text-white font-medium">{alert.stock}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Min. Threshold</div>
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-wine" />
                      <span className="text-white font-medium">{alert.threshold}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gold/10">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-2 rounded-lg font-medium hover:shadow-lg hover:shadow-gold/20 transition-all"
                  >
                    Reorder Stock
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
