import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Wine, Lock, Mail } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#722F37]/10 via-transparent to-[#D4AF37]/5" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-[#141414] rounded-2xl p-8 shadow-2xl border border-gold/10">
          <div className="flex flex-col items-center mb-8">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="w-16 h-16 bg-gradient-to-br from-gold to-wine rounded-full flex items-center justify-center mb-4"
            >
              <Wine className="w-8 h-8 text-black" />
            </motion.div>
            <h1 className="text-3xl font-semibold text-white mb-2">Liquor Inventory</h1>
            <p className="text-muted-foreground">Premium Management System</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm text-muted-foreground mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
                  placeholder="admin@liquorstore.com"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm text-muted-foreground mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full bg-gradient-to-r from-gold to-[#C19A6B] text-black py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
            >
              Sign In
            </motion.button>
          </form>

          <div className="mt-6 text-center">
            <a href="#" className="text-sm text-gold hover:text-gold/80 transition-colors">
              Forgot password?
            </a>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
