import { motion } from "motion/react";
import { Plus, Edit2, Trash2, Search, Mail, Phone, MapPin } from "lucide-react";
import { useState } from "react";

const suppliers = [
  {
    id: 1,
    name: "Premium Spirits Co.",
    contact: "John Smith",
    email: "john@premiumspirits.com",
    phone: "+1 (555) 123-4567",
    location: "New York, USA",
    products: 145,
  },
  {
    id: 2,
    name: "European Wine Imports",
    contact: "Marie Dubois",
    email: "marie@eurowine.com",
    phone: "+33 1 2345 6789",
    location: "Paris, France",
    products: 89,
  },
  {
    id: 3,
    name: "Global Liquor Distributors",
    contact: "Robert Chen",
    email: "robert@globalliquor.com",
    phone: "+1 (555) 987-6543",
    location: "Los Angeles, USA",
    products: 203,
  },
  {
    id: 4,
    name: "Scottish Whisky Merchants",
    contact: "William MacLeod",
    email: "william@scotchmerchants.co.uk",
    phone: "+44 20 7123 4567",
    location: "Edinburgh, UK",
    products: 67,
  },
  {
    id: 5,
    name: "Mexican Spirits Export",
    contact: "Carlos Rodriguez",
    email: "carlos@mexspirits.mx",
    phone: "+52 55 1234 5678",
    location: "Mexico City, Mexico",
    products: 42,
  },
];

export default function Suppliers() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Suppliers</h1>
          <p className="text-muted-foreground">Manage your supplier relationships</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Supplier
        </motion.button>
      </div>

      {/* Search */}
      <div className="bg-surface rounded-xl p-6 border border-gold/10">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search suppliers by name, contact, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
          />
        </div>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {suppliers.map((supplier, index) => (
          <motion.div
            key={supplier.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-surface rounded-xl p-6 border border-gold/10 hover:border-gold/20 transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold text-white mb-1">{supplier.name}</h3>
                <p className="text-sm text-muted-foreground">{supplier.contact}</p>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 text-gold hover:bg-gold/10 rounded-lg transition-colors">
                  <Edit2 className="w-4 h-4" />
                </button>
                <button className="p-2 text-wine hover:bg-wine/10 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-gold" />
                <span className="text-muted-foreground">{supplier.email}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Phone className="w-4 h-4 text-gold" />
                <span className="text-muted-foreground">{supplier.phone}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <MapPin className="w-4 h-4 text-gold" />
                <span className="text-muted-foreground">{supplier.location}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gold/10">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Products Supplied</span>
                <span className="text-lg font-semibold text-white">{supplier.products}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
