import { motion } from "motion/react";
import { Plus, ArrowUpCircle, ArrowDownCircle, Search, Filter } from "lucide-react";
import { useState } from "react";

const movements = [
  {
    id: 1,
    product: "Jack Daniel's No. 7",
    type: "IN",
    quantity: 50,
    date: "2026-04-12 09:30",
    user: "Admin User",
    notes: "Stock replenishment",
  },
  {
    id: 2,
    product: "Château Margaux 2015",
    type: "OUT",
    quantity: 12,
    date: "2026-04-12 08:15",
    user: "Sales Manager",
    notes: "Customer order #1245",
  },
  {
    id: 3,
    product: "Grey Goose Vodka",
    type: "IN",
    quantity: 30,
    date: "2026-04-11 16:45",
    user: "Admin User",
    notes: "New shipment",
  },
  {
    id: 4,
    product: "Macallan 18 Year",
    type: "IN",
    quantity: 20,
    date: "2026-04-11 14:20",
    user: "Warehouse Manager",
    notes: "Premium stock",
  },
  {
    id: 5,
    product: "Patrón Silver Tequila",
    type: "OUT",
    quantity: 8,
    date: "2026-04-11 11:00",
    user: "Sales Manager",
    notes: "Walk-in customer",
  },
  {
    id: 6,
    product: "Moët & Chandon Brut",
    type: "IN",
    quantity: 25,
    date: "2026-04-10 15:30",
    user: "Admin User",
    notes: "Weekly delivery",
  },
  {
    id: 7,
    product: "Hennessy V.S",
    type: "OUT",
    quantity: 15,
    date: "2026-04-10 10:15",
    user: "Sales Manager",
    notes: "Restaurant order",
  },
  {
    id: 8,
    product: "Johnnie Walker Blue",
    type: "IN",
    quantity: 10,
    date: "2026-04-09 13:45",
    user: "Warehouse Manager",
    notes: "Special order arrival",
  },
];

export default function Inventory() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Inventory Movements</h1>
          <p className="text-muted-foreground">Track all stock entries and exits</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Movement
        </motion.button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
              <ArrowUpCircle className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">135</div>
              <div className="text-sm text-muted-foreground">Stock In (This Week)</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-wine/10 rounded-lg flex items-center justify-center">
              <ArrowDownCircle className="w-6 h-6 text-wine" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">89</div>
              <div className="text-sm text-muted-foreground">Stock Out (This Week)</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gold/10 rounded-lg flex items-center justify-center">
              <ArrowUpCircle className="w-6 h-6 text-gold" />
            </div>
            <div>
              <div className="text-2xl font-semibold text-white">+46</div>
              <div className="text-sm text-muted-foreground">Net Movement</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filters */}
      <div className="bg-surface rounded-xl p-6 border border-gold/10">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by product name or user..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
            />
          </div>
          <button className="flex items-center gap-2 bg-surface-elevated border border-gold/10 px-4 py-3 rounded-lg text-white hover:border-gold/30 transition-all">
            <Filter className="w-5 h-5" />
            Filter
          </button>
        </div>
      </div>

      {/* Movements Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-surface rounded-xl border border-gold/10 overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gold/10">
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Product
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Type
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Quantity
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Date & Time
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  User
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Notes
                </th>
              </tr>
            </thead>
            <tbody>
              {movements.map((movement, index) => (
                <motion.tr
                  key={movement.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.03 }}
                  className="border-b border-gold/5 hover:bg-surface-elevated transition-colors"
                >
                  <td className="px-6 py-4 text-white font-medium">{movement.product}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {movement.type === "IN" ? (
                        <>
                          <ArrowUpCircle className="w-4 h-4 text-green-500" />
                          <span className="text-green-500 font-medium">IN</span>
                        </>
                      ) : (
                        <>
                          <ArrowDownCircle className="w-4 h-4 text-wine" />
                          <span className="text-wine font-medium">OUT</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-white">{movement.quantity}</td>
                  <td className="px-6 py-4 text-muted-foreground">{movement.date}</td>
                  <td className="px-6 py-4 text-muted-foreground">{movement.user}</td>
                  <td className="px-6 py-4 text-muted-foreground">{movement.notes}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
