import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Search, Filter, ChevronDown, ShoppingBag, Star } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const MOCK_PRODUCTS = [
  { id: "1", name: "Macallan 25 Year Old", brand: "The Macallan", price: 1999.0, category: "Single Malt Scotch", rating: 4.9, stock: 3, image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80" },
  { id: "2", name: "Dom Pérignon Vintage 2012", brand: "Dom Pérignon", price: 249.99, category: "Champagne", rating: 4.8, stock: 15, image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?w=800&q=80" },
  { id: "3", name: "Yamazaki 18 Year Old", brand: "Suntory", price: 899.99, category: "Japanese Whisky", rating: 5.0, stock: 0, image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80" },
  { id: "4", name: "Opus One 2018", brand: "Opus One", price: 450.0, category: "Red Blend", rating: 4.9, stock: 24, image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?w=800&q=80" },
  { id: "5", name: "Clase Azul Reposado", brand: "Clase Azul", price: 169.99, category: "Tequila", rating: 4.7, stock: 12, image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80" },
  { id: "6", name: "Louis XIII Cognac", brand: "Remy Martin", price: 3999.0, category: "Cognac", rating: 5.0, stock: 1, image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80" },
  { id: "7", name: "Cristal Brut 2014", brand: "Louis Roederer", price: 349.99, category: "Champagne", rating: 4.8, stock: 8, image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?w=800&q=80" },
  { id: "8", name: "Pappy Van Winkle 15 Yr", brand: "Old Rip Van Winkle", price: 1499.0, category: "Bourbon", rating: 4.9, stock: 2, image: "https://images.unsplash.com/photo-1762983039830-9606927656da?w=800&q=80" },
];

export default function ProductCatalog() {
  const [activeCategory, setActiveCategory] = useState("All");

  return (
    <div className="flex-1 bg-[#0a0a0a] min-h-screen">
      {/* Page Header */}
      <div className="bg-[#121212] border-b border-white/5 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
            <div>
              <h1 className="text-4xl font-bold tracking-tight text-white mb-2">Spirits & Wine</h1>
              <p className="text-white/50">Explore our curated collection of premium beverages.</p>
            </div>
            <div className="text-sm font-medium text-white/40">Showing {MOCK_PRODUCTS.length} results</div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 flex flex-col lg:flex-row gap-12">
        {/* Filters Sidebar */}
        <aside className="w-full lg:w-64 shrink-0 space-y-10">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-6 flex items-center gap-2">
              <Filter className="w-4 h-4 text-gold" /> Categories
            </h3>
            <div className="space-y-3">
              {["All", "Single Malt Scotch", "Champagne", "Japanese Whisky", "Red Blend", "Tequila", "Cognac", "Bourbon"].map((cat) => (
                <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                  <input
                    type="radio"
                    name="category"
                    checked={activeCategory === cat}
                    onChange={() => setActiveCategory(cat)}
                    className="w-4 h-4 bg-[#1a1a1a] border-white/20 text-gold focus:ring-gold focus:ring-offset-black"
                  />
                  <span className={`text-sm transition-colors ${activeCategory === cat ? "text-gold font-bold" : "text-white/70 group-hover:text-white"}`}>
                    {cat}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-6">Price Range</h3>
            <div className="space-y-4">
              <input
                type="range"
                min="0"
                max="5000"
                defaultValue="5000"
                className="w-full accent-gold bg-[#1a1a1a]"
              />
              <div className="flex items-center justify-between text-xs text-white/50 font-medium">
                <span>$0</span>
                <span>$5,000+</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-white mb-6">Brand</h3>
            <div className="space-y-3 max-h-48 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
              {Array.from(new Set(MOCK_PRODUCTS.map(p => p.brand))).map((brand) => (
                <label key={brand} className="flex items-center gap-3 cursor-pointer group">
                  <input
                    type="checkbox"
                    className="w-4 h-4 rounded-sm bg-[#1a1a1a] border-white/20 text-gold focus:ring-gold focus:ring-offset-black"
                  />
                  <span className="text-sm text-white/70 group-hover:text-white transition-colors">{brand}</span>
                </label>
              ))}
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-1">
          {/* Top Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-8">
            <div className="relative w-full sm:w-auto flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <input
                type="text"
                placeholder="Search products..."
                className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg pl-12 pr-4 py-3 text-sm text-white placeholder:text-white/40 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold transition-colors"
              />
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <span className="text-sm text-white/50 whitespace-nowrap">Sort by:</span>
              <button className="flex items-center justify-between gap-4 bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-sm text-white min-w-[160px] hover:border-white/30 transition-colors">
                Featured <ChevronDown className="w-4 h-4 text-white/40" />
              </button>
            </div>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
            {MOCK_PRODUCTS.filter(p => activeCategory === "All" || p.category === activeCategory).map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="group flex flex-col bg-[#121212] rounded-xl border border-white/5 overflow-hidden hover:border-gold/30 hover:bg-[#1a1a1a] transition-all"
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-black flex items-center justify-center p-8">
                  {/* Stock Badge */}
                  {product.stock === 0 && (
                    <div className="absolute top-4 left-4 z-20 bg-wine text-white text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded">
                      Out of Stock
                    </div>
                  )}
                  {product.stock > 0 && product.stock <= 3 && (
                    <div className="absolute top-4 left-4 z-20 bg-gold text-black text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded">
                      Low Stock
                    </div>
                  )}
                  
                  {/* Rating Badge */}
                  <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-md border border-white/10 px-2 py-1 rounded flex items-center gap-1">
                    <Star className="w-3 h-3 text-gold fill-gold" />
                    <span className="text-xs font-bold text-white">{product.rating}</span>
                  </div>

                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className={`relative z-10 w-auto h-full object-contain filter drop-shadow-2xl transition-transform duration-700 group-hover:scale-110 ${product.stock === 0 ? "opacity-50 grayscale" : ""}`}
                  />
                  
                  {/* Hover Quick Add */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 z-20">
                    <button 
                      disabled={product.stock === 0}
                      className="w-full bg-gold text-black font-bold py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-white/10 disabled:text-white"
                    >
                      <ShoppingBag className="w-4 h-4" /> 
                      {product.stock === 0 ? "Sold Out" : "Quick Add"}
                    </button>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col">
                  <div className="text-xs font-bold text-gold uppercase tracking-wider mb-2">
                    {product.brand}
                  </div>
                  <Link to={`/shop/products/${product.id}`}>
                    <h3 className="text-lg font-bold text-white mb-1 group-hover:text-gold transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                  </Link>
                  <p className="text-sm text-white/50 mb-4">{product.category}</p>
                  
                  <div className="mt-auto">
                    <span className="text-xl font-bold text-white">${product.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pagination */}
          <div className="mt-12 flex items-center justify-center gap-2">
            <button className="w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:border-white/30 transition-colors">
              Prev
            </button>
            <button className="w-10 h-10 rounded-lg bg-gold text-black font-bold flex items-center justify-center">
              1
            </button>
            <button className="w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-white hover:border-white/30 transition-colors">
              2
            </button>
            <button className="w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-white hover:border-white/30 transition-colors">
              3
            </button>
            <span className="text-white/50 px-2">...</span>
            <button className="w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:border-white/30 transition-colors">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}