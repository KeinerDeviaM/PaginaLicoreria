import { motion } from "motion/react";
import { Link } from "react-router";
import { ChevronRight, Star, ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const featuredProducts = [
  {
    id: "1",
    name: "Macallan 25 Year Old",
    brand: "The Macallan",
    price: 1999.0,
    category: "Single Malt Scotch",
    image: "https://images.unsplash.com/photo-1762983039830-9606927656da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBsaXF1b3IlMjBib3R0bGUlMjBkYXJrfGVufDF8fHx8MTc3NjA0NzgwM3ww&ixlib=rb-4.1.0&q=80&w=1080",
    rating: 4.9,
  },
  {
    id: "2",
    name: "Dom Pérignon Vintage 2012",
    brand: "Dom Pérignon",
    price: 249.99,
    category: "Champagne",
    image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjB3aW5lJTIwYm90dGxlJTIwcG91cmluZ3xlbnwxfHx8fDE3NzYwNDc4MDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    rating: 4.8,
  },
  {
    id: "3",
    name: "Yamazaki 18 Year Old",
    brand: "Suntory",
    price: 899.99,
    category: "Japanese Whisky",
    image: "https://images.unsplash.com/photo-1762983039830-9606927656da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBsaXF1b3IlMjBib3R0bGUlMjBkYXJrfGVufDF8fHx8MTc3NjA0NzgwM3ww&ixlib=rb-4.1.0&q=80&w=1080",
    rating: 5.0,
  },
  {
    id: "4",
    name: "Opus One 2018",
    brand: "Opus One",
    price: 450.0,
    category: "Red Blend",
    image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjB3aW5lJTIwYm90dGxlJTIwcG91cmluZ3xlbnwxfHx8fDE3NzYwNDc4MDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    rating: 4.9,
  },
];

const categories = [
  { name: "Single Malt", count: "124", image: "https://images.unsplash.com/photo-1762983039830-9606927656da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400" },
  { name: "Vintage Wine", count: "312", image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400" },
  { name: "Champagne", count: "89", image: "https://images.unsplash.com/photo-1762983039830-9606927656da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400" },
  { name: "Rare Spirits", count: "45", image: "https://images.unsplash.com/photo-1726884979024-a618202c4a3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400" },
];

export default function StoreHome() {
  return (
    <div className="flex flex-col flex-1 bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1762983039830-9606927656da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBsaXF1b3IlMjBib3R0bGUlMjBkYXJrfGVufDF8fHx8MTc3NjA0NzgwM3ww&ixlib=rb-4.1.0&q=80&w=1920"
            alt="Luxury Bar"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold/30 bg-gold/5 backdrop-blur-sm mb-6">
              <span className="w-2 h-2 rounded-full bg-gold" />
              <span className="text-xs font-semibold text-gold uppercase tracking-wider">New Allocation Available</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6 leading-tight">
              Elevate Your <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-wine">Collection.</span>
            </h1>
            <p className="text-lg text-white/70 mb-10 leading-relaxed max-w-xl font-light">
              Discover our curated selection of rare spirits, vintage wines, and premium champagnes. Exclusive bottles for the discerning connoisseur.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <Link
                to="/shop/products"
                className="w-full sm:w-auto px-8 py-4 bg-gold text-black font-bold tracking-wide uppercase text-sm hover:bg-gold/90 transition-colors flex items-center justify-center gap-2"
              >
                Shop Collection <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/shop/products"
                className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white/20 text-white font-bold tracking-wide uppercase text-sm hover:bg-white/5 transition-colors flex items-center justify-center"
              >
                View Rare Finds
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-24 max-w-7xl mx-auto px-6 w-full">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-white mb-2">Explore by Category</h2>
            <p className="text-white/50">Curated selections for every palate.</p>
          </div>
          <Link to="/shop/products" className="hidden sm:flex items-center gap-2 text-gold hover:text-gold/80 transition-colors text-sm font-semibold uppercase tracking-wider">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, idx) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              viewport={{ once: true }}
              className="group relative aspect-[3/4] rounded-xl overflow-hidden cursor-pointer"
            >
              <ImageWithFallback
                src={category.image}
                alt={category.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
              <div className="absolute bottom-0 left-0 p-6 w-full">
                <h3 className="text-xl font-bold text-white mb-1">{category.name}</h3>
                <p className="text-sm text-gold font-medium">{category.count} Items</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-[#121212] border-t border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 w-full">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-white mb-2">Featured Selections</h2>
              <p className="text-white/50">Exceptional bottles hand-picked by our sommeliers.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1, duration: 0.5 }}
                viewport={{ once: true }}
                className="group flex flex-col bg-[#1a1a1a] rounded-xl border border-white/5 overflow-hidden hover:border-gold/30 transition-colors"
              >
                <Link to={`/shop/products/${product.id}`} className="relative aspect-square overflow-hidden bg-black flex items-center justify-center p-8">
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent z-0" />
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="relative z-10 w-auto h-full object-contain filter drop-shadow-2xl transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Rating Badge */}
                  <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-md border border-white/10 px-2 py-1 rounded flex items-center gap-1">
                    <Star className="w-3 h-3 text-gold fill-gold" />
                    <span className="text-xs font-bold text-white">{product.rating}</span>
                  </div>
                </Link>
                
                <div className="p-6 flex-1 flex flex-col">
                  <div className="text-xs font-bold text-gold uppercase tracking-wider mb-2">
                    {product.brand}
                  </div>
                  <Link to={`/shop/products/${product.id}`}>
                    <h3 className="text-lg font-bold text-white mb-1 group-hover:text-gold transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                  </Link>
                  <p className="text-sm text-white/50 mb-4">{product.category}</p>
                  
                  <div className="mt-auto flex items-center justify-between">
                    <span className="text-xl font-bold text-white">${product.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    <button className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-gold hover:text-black hover:border-gold transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Promotional Banner */}
      <section className="py-24 max-w-7xl mx-auto px-6 w-full">
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#1a1112] to-[#0a0a0a] border border-wine/20 p-12 lg:p-20 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1726884979024-a618202c4a3c?q=80&w=1920')] opacity-10 mix-blend-overlay bg-cover bg-center" />
          
          <div className="relative z-10 max-w-xl">
            <h2 className="text-3xl lg:text-5xl font-bold tracking-tight text-white mb-6">
              Private Tasting Collection
            </h2>
            <p className="text-lg text-white/70 mb-8 leading-relaxed">
              Experience our most exclusive, limited-allocation wines and spirits. Reserved for the true connoisseur. Includes complimentary sommelier consultation.
            </p>
            <button className="px-8 py-4 bg-wine text-white font-bold tracking-wide uppercase text-sm hover:bg-wine/90 transition-colors rounded-sm shadow-[0_0_20px_rgba(114,47,55,0.3)]">
              Discover the Collection
            </button>
          </div>
          
          <div className="relative z-10 w-full max-w-md aspect-square rounded-full border border-wine/30 flex items-center justify-center p-8">
            <div className="absolute inset-0 rounded-full border border-gold/20 scale-110" />
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1726884979024-a618202c4a3c?q=80&w=800"
              alt="Wine Pouring"
              className="w-full h-full object-cover rounded-full filter sepia-[0.3] hover:sepia-0 transition-all duration-700"
            />
          </div>
        </div>
      </section>
    </div>
  );
}