import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Wine, Mail, ArrowLeft, CheckCircle2 } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 relative overflow-hidden py-12">
      <div className="absolute inset-0 bg-gradient-to-br from-[#722F37]/10 via-transparent to-[#D4AF37]/5" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-[#141414] rounded-2xl p-8 shadow-2xl border border-gold/10">
          <div className="flex flex-col items-center mb-8">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="w-16 h-16 bg-gradient-to-br from-gold to-wine rounded-full flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(212,175,55,0.3)]"
            >
              <Wine className="w-8 h-8 text-black" />
            </motion.div>
            <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Reset Password</h1>
            <p className="text-white/50 text-center max-w-xs">
              {submitted 
                ? "Check your email for reset instructions." 
                : "Enter your email and we'll send you a link to reset your password."}
            </p>
          </div>

          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white/70 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-white/40 focus:border-gold/50 focus:outline-none focus:ring-1 focus:ring-gold/50 transition-all"
                    placeholder="admin@liquorstore.com"
                    required
                  />
                </div>
              </div>

              <div className="pt-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full bg-gold text-black py-4 rounded-lg font-bold tracking-wider uppercase text-sm hover:bg-white transition-colors shadow-[0_0_20px_rgba(212,175,55,0.2)]"
                >
                  Send Reset Link
                </motion.button>
              </div>
            </form>
          ) : (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-6 text-center"
            >
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">Email Sent</h3>
              <p className="text-sm text-white/60 mb-6">
                We've sent a password reset link to <strong>{email}</strong>.
              </p>
              <button 
                onClick={() => setSubmitted(false)}
                className="text-sm text-gold hover:text-white transition-colors"
              >
                Didn't receive it? Try again
              </button>
            </motion.div>
          )}

          <div className="mt-8 text-center border-t border-white/10 pt-6">
            <Link to="/login" className="inline-flex items-center gap-2 text-white/50 text-sm hover:text-white transition-colors">
              <ArrowLeft className="w-4 h-4" /> Back to sign in
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}