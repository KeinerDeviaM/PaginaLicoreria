import { motion } from "motion/react";
import {
  Package,
  AlertTriangle,
  FolderTree,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Clock,
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const statsCards = [
  {
    title: "Total Products",
    value: "1,248",
    change: "+12%",
    trend: "up",
    icon: Package,
    color: "gold",
  },
  {
    title: "Low Stock Items",
    value: "23",
    change: "-5%",
    trend: "down",
    icon: AlertTriangle,
    color: "wine",
  },
  {
    title: "Categories",
    value: "18",
    change: "+2",
    trend: "up",
    icon: FolderTree,
    color: "gold",
  },
  {
    title: "Inventory Value",
    value: "$284,520",
    change: "+8.4%",
    trend: "up",
    icon: DollarSign,
    color: "gold",
  },
];

const inventoryData = [
  { month: "Jan", value: 245000 },
  { month: "Feb", value: 268000 },
  { month: "Mar", value: 252000 },
  { month: "Apr", value: 275000 },
  { month: "May", value: 284520 },
  { month: "Jun", value: 295000 },
];

const categoryData = [
  { name: "Whiskey", value: 320, color: "#D4AF37" },
  { name: "Wine", value: 280, color: "#722F37" },
  { name: "Vodka", value: 250, color: "#C19A6B" },
  { name: "Rum", value: 180, color: "#8B4513" },
  { name: "Tequila", value: 140, color: "#A0522D" },
  { name: "Others", value: 78, color: "#5a5a5a" },
];

const recentActivity = [
  { action: "Stock added", product: "Jack Daniel's No. 7", qty: "+50", time: "5 min ago" },
  { action: "Stock removed", product: "Château Margaux 2015", qty: "-12", time: "23 min ago" },
  { action: "Low stock alert", product: "Grey Goose Vodka", qty: "8 left", time: "1 hour ago" },
  { action: "New product", product: "Macallan 18 Year", qty: "+30", time: "2 hours ago" },
  { action: "Stock updated", product: "Patrón Silver", qty: "+25", time: "3 hours ago" },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your inventory overview.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-surface rounded-xl p-6 border border-gold/10 hover:border-gold/20 transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <div
                className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  stat.color === "gold"
                    ? "bg-gold/10 text-gold"
                    : "bg-wine/10 text-wine"
                }`}
              >
                <stat.icon className="w-6 h-6" />
              </div>
              <div
                className={`flex items-center gap-1 text-sm font-medium ${
                  stat.trend === "up" ? "text-green-500" : "text-wine"
                }`}
              >
                {stat.trend === "up" ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                {stat.change}
              </div>
            </div>
            <div className="text-3xl font-semibold text-white mb-1">{stat.value}</div>
            <div className="text-sm text-muted-foreground">{stat.title}</div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inventory Value Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-surface rounded-xl p-6 border border-gold/10"
        >
          <h2 className="text-xl font-semibold text-white mb-6">Inventory Value Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={inventoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(212, 175, 55, 0.1)" />
              <XAxis dataKey="month" stroke="#a3a3a3" key="xaxis-inventory" />
              <YAxis stroke="#a3a3a3" key="yaxis-inventory" />
              <Tooltip
                key="tooltip-inventory"
                contentStyle={{
                  backgroundColor: "#141414",
                  border: "1px solid rgba(212, 175, 55, 0.2)",
                  borderRadius: "8px",
                }}
                labelStyle={{ color: "#ffffff" }}
              />
              <Line
                key="line-inventory"
                type="monotone"
                dataKey="value"
                stroke="#D4AF37"
                strokeWidth={3}
                dot={{ fill: "#D4AF37", r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Category Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-surface rounded-xl p-6 border border-gold/10"
        >
          <h2 className="text-xl font-semibold text-white mb-6">Category Distribution</h2>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                key="pie-categories"
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {categoryData.map((entry) => (
                  <Cell key={`category-${entry.name}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                key="tooltip-categories"
                contentStyle={{
                  backgroundColor: "#141414",
                  border: "1px solid rgba(212, 175, 55, 0.2)",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {categoryData.slice(0, 4).map((cat) => (
              <div key={cat.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: cat.color }}
                  />
                  <span className="text-muted-foreground">{cat.name}</span>
                </div>
                <span className="text-white font-medium">{cat.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-surface rounded-xl p-6 border border-gold/10"
      >
        <h2 className="text-xl font-semibold text-white mb-6">Recent Activity</h2>
        <div className="space-y-4">
          {recentActivity.map((activity, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-surface-elevated rounded-lg border border-gold/5 hover:border-gold/10 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <div className="text-white font-medium">{activity.product}</div>
                  <div className="text-sm text-muted-foreground">{activity.action}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white font-medium">{activity.qty}</div>
                <div className="text-sm text-muted-foreground">{activity.time}</div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
