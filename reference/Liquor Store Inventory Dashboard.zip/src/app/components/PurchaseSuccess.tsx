import { Link } from "react-router";
import { motion } from "motion/react";
import { CheckCircle2, Download, Package, ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function PurchaseSuccess() {
  return (
    <div className="flex-1 bg-[#0a0a0a] min-h-screen flex items-center justify-center py-20">
      <div className="max-w-2xl w-full px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#121212] border border-white/5 rounded-3xl p-10 md:p-16 text-center shadow-2xl shadow-gold/5"
        >
          <div className="w-24 h-24 bg-gradient-to-br from-gold/20 to-gold/5 rounded-full flex items-center justify-center mx-auto mb-8 border border-gold/20 relative">
            <div className="absolute inset-0 bg-gold/10 rounded-full animate-ping" />
            <CheckCircle2 className="w-12 h-12 text-gold relative z-10" />
          </div>

          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-white mb-4">
            Purchase Completed
          </h1>
          <p className="text-lg text-white/60 mb-10 max-w-md mx-auto">
            Thank you for your order. We've sent a confirmation email with your order details and tracking information.
          </p>

          <div className="bg-[#1a1a1a] rounded-2xl border border-white/5 p-8 mb-10 text-left">
            <div className="flex justify-between items-center mb-6 pb-6 border-b border-white/10">
              <div>
                <div className="text-xs font-bold text-white/40 uppercase tracking-wider mb-1">Order Number</div>
                <div className="text-xl font-bold text-white tracking-widest font-mono">ORD-2026-8924</div>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-white/40 uppercase tracking-wider mb-1">Date</div>
                <div className="text-white font-medium">Apr 13, 2026</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black rounded border border-white/5 p-1">
                    <ImageWithFallback src="https://images.unsplash.com/photo-1762983039830-9606927656da?w=100" alt="Item" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <div className="font-bold text-white text-sm">Macallan 25 Year Old</div>
                    <div className="text-xs text-white/50">Qty: 1</div>
                  </div>
                </div>
                <div className="font-bold text-white">$1,999.00</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black rounded border border-white/5 p-1">
                    <ImageWithFallback src="https://images.unsplash.com/photo-1726884979024-a618202c4a3c?w=100" alt="Item" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <div className="font-bold text-white text-sm">Dom Pérignon 2012</div>
                    <div className="text-xs text-white/50">Qty: 2</div>
                  </div>
                </div>
                <div className="font-bold text-white">$499.98</div>
              </div>
            </div>

            <div className="border-t border-white/10 mt-6 pt-6">
              <div className="flex justify-between items-end">
                <span className="text-sm font-bold text-white/50 uppercase tracking-wider">Total Paid</span>
                <span className="text-2xl font-bold text-gold">$2,723.90</span>
              </div>
              <div className="text-right text-xs text-white/40 mt-1">Paid via Credit Card ending in 4242</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/shop/receipt"
              className="w-full sm:w-auto px-8 py-4 bg-[#1a1a1a] border border-white/10 text-white font-bold uppercase tracking-wider text-sm rounded-lg hover:border-gold hover:text-gold transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> Download Invoice
            </Link>
            <Link
              to="/shop"
              className="w-full sm:w-auto px-8 py-4 bg-gold text-black font-bold uppercase tracking-wider text-sm rounded-lg hover:bg-white transition-colors flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.2)]"
            >
              Return Home <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}