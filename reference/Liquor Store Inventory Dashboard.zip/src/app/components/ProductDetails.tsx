import { useState } from "react";
import { Link, useParams } from "react-router";
import { motion } from "motion/react";
import { Star, ChevronRight, Minus, Plus, ShoppingBag, ShieldCheck, Truck, RotateCcw } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function ProductDetails() {
  const { id } = useParams();
  const [quantity, setQuantity] = useState(1);

  // Mock product
  const product = {
    id: id || "1",
    name: "Macallan 25 Year Old",
    brand: "The Macallan",
    price: 1999.0,
    category: "Single Malt Scotch Whisky",
    region: "Speyside, Scotland",
    abv: "43%",
    volume: "750ml",
    rating: 4.9,
    reviews: 124,
    stock: 3,
    description: "The Macallan 25 Years Old Sherry Oak is an exquisite single malt scotch whisky. Matured exclusively in hand-picked Oloroso sherry seasoned oak casks from Jerez, Spain, for twenty-five years, this special whisky delivers an intensely rich and full flavor profile characterized by citrus, dried fruits, and wood smoke.",
    tastingNotes: ["Rich Mahogany", "Citrus, cinnamon, sherry, and wood smoke", "Full and rich, with dried fruits and a hint of wood smoke", "Long, with dried fruit, wood smoke, and spice"],
    images: [
      "https://images.unsplash.com/photo-1762983039830-9606927656da?w=1080&q=80",
      "https://images.unsplash.com/photo-1762983039830-9606927656da?w=1080&q=80",
    ],
  };

  const [activeImage, setActiveImage] = useState(product.images[0]);

  return (
    <div className="flex-1 bg-[#0a0a0a] min-h-screen">
      {/* Breadcrumbs */}
      <div className="bg-[#121212] border-b border-white/5 py-4">
        <div className="max-w-7xl mx-auto px-6 flex items-center text-xs font-medium text-white/40 uppercase tracking-widest gap-2">
          <Link to="/shop" className="hover:text-gold transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/shop/products" className="hover:text-gold transition-colors">Spirits</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-white">{product.brand}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex flex-col lg:flex-row gap-16">
          {/* Image Gallery */}
          <div className="w-full lg:w-1/2 flex gap-6">
            <div className="flex flex-col gap-4">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(img)}
                  className={`w-20 h-24 bg-[#121212] rounded-lg border overflow-hidden transition-all ${activeImage === img ? "border-gold" : "border-transparent hover:border-white/20"}`}
                >
                  <ImageWithFallback src={img} alt={`Thumb ${idx}`} className="w-full h-full object-contain p-2" />
                </button>
              ))}
            </div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="flex-1 bg-[#121212] rounded-2xl border border-white/5 aspect-[4/5] relative flex items-center justify-center p-12 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent z-0" />
              <ImageWithFallback src={activeImage} alt={product.name} className="relative z-10 w-auto h-full object-contain filter drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)]" />
            </motion.div>
          </div>

          {/* Product Details */}
          <div className="w-full lg:w-1/2 flex flex-col">
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-bold text-gold uppercase tracking-widest">{product.brand}</span>
                <div className="flex items-center gap-2 bg-[#1a1a1a] px-3 py-1.5 rounded-full border border-white/10">
                  <Star className="w-4 h-4 text-gold fill-gold" />
                  <span className="text-sm font-bold text-white">{product.rating}</span>
                  <span className="text-xs text-white/40">({product.reviews} reviews)</span>
                </div>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold tracking-tight text-white mb-4 leading-tight">{product.name}</h1>
              <p className="text-xl text-white/60 mb-6">{product.category} • {product.region}</p>
              <div className="text-4xl font-bold text-white">${product.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
            </div>

            <p className="text-white/70 leading-relaxed mb-8">{product.description}</p>

            <div className="grid grid-cols-2 gap-6 mb-10 py-8 border-y border-white/10">
              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white/40 mb-1">Volume</span>
                <span className="text-lg font-medium text-white">{product.volume}</span>
              </div>
              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white/40 mb-1">ABV</span>
                <span className="text-lg font-medium text-white">{product.abv}</span>
              </div>
              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white/40 mb-1">Availability</span>
                {product.stock > 0 ? (
                  <span className="text-lg font-medium text-emerald-400">In Stock ({product.stock})</span>
                ) : (
                  <span className="text-lg font-medium text-wine">Out of Stock</span>
                )}
              </div>
              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white/40 mb-1">SKU</span>
                <span className="text-lg font-medium text-white">MAC-25Y-001</span>
              </div>
            </div>

            {/* Add to Cart Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <div className="flex items-center justify-between bg-[#1a1a1a] border border-white/10 rounded-lg p-2 sm:w-1/3">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-lg font-bold text-white w-10 text-center">{quantity}</span>
                <button 
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-10 h-10 rounded flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              
              <button 
                disabled={product.stock === 0}
                className="flex-1 bg-gold text-black font-bold text-lg rounded-lg flex items-center justify-center gap-3 hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-white/10 disabled:text-white py-4 sm:py-0 shadow-[0_0_20px_rgba(212,175,55,0.2)]"
              >
                <ShoppingBag className="w-5 h-5" /> 
                {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 text-sm text-white/70">
                <ShieldCheck className="w-5 h-5 text-gold" /> Guaranteed Authentic
              </div>
              <div className="flex items-center gap-3 text-sm text-white/70">
                <Truck className="w-5 h-5 text-gold" /> Secure Shipping
              </div>
              <div className="flex items-center gap-3 text-sm text-white/70">
                <RotateCcw className="w-5 h-5 text-gold" /> 30-Day Returns
              </div>
            </div>
          </div>
        </div>

        {/* Specifications */}
        <div className="mt-24 border-t border-white/10 pt-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            <div>
              <h2 className="text-2xl font-bold text-white mb-8">Tasting Notes</h2>
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gold mb-2">Color</h4>
                  <p className="text-white/70">{product.tastingNotes[0]}</p>
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gold mb-2">Nose</h4>
                  <p className="text-white/70">{product.tastingNotes[1]}</p>
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gold mb-2">Palate</h4>
                  <p className="text-white/70">{product.tastingNotes[2]}</p>
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gold mb-2">Finish</h4>
                  <p className="text-white/70">{product.tastingNotes[3]}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-[#121212] rounded-2xl p-10 border border-white/5 h-fit">
              <h2 className="text-2xl font-bold text-white mb-8">Product Details</h2>
              <ul className="space-y-4">
                <li className="flex justify-between py-3 border-b border-white/5">
                  <span className="text-white/50">Brand</span>
                  <span className="font-medium text-white">{product.brand}</span>
                </li>
                <li className="flex justify-between py-3 border-b border-white/5">
                  <span className="text-white/50">Category</span>
                  <span className="font-medium text-white">{product.category}</span>
                </li>
                <li className="flex justify-between py-3 border-b border-white/5">
                  <span className="text-white/50">Region</span>
                  <span className="font-medium text-white">{product.region}</span>
                </li>
                <li className="flex justify-between py-3 border-b border-white/5">
                  <span className="text-white/50">ABV</span>
                  <span className="font-medium text-white">{product.abv}</span>
                </li>
                <li className="flex justify-between py-3">
                  <span className="text-white/50">Volume</span>
                  <span className="font-medium text-white">{product.volume}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}