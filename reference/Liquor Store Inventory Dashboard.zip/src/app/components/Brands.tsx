import { motion } from "motion/react";
import { Plus, Edit2, Trash2, Award, Search } from "lucide-react";
import { useState } from "react";

const brands = [
  { id: 1, name: "Jack Daniel's", products: 45, origin: "USA" },
  { id: 2, name: "Château Margaux", products: 12, origin: "France" },
  { id: 3, name: "Grey Goose", products: 28, origin: "France" },
  { id: 4, name: "Macallan", products: 18, origin: "Scotland" },
  { id: 5, name: "Patrón", products: 22, origin: "Mexico" },
  { id: 6, name: "Moët & Chandon", products: 34, origin: "France" },
  { id: 7, name: "Johnnie Walker", products: 56, origin: "Scotland" },
  { id: 8, name: "Hennessy", products: 41, origin: "France" },
  { id: 9, name: "Bacardi", products: 38, origin: "Cuba" },
  { id: 10, name: "Absolut", products: 29, origin: "Sweden" },
  { id: 11, name: "Rémy Martin", products: 15, origin: "France" },
  { id: 12, name: "Chivas Regal", products: 31, origin: "Scotland" },
];

export default function Brands() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Brands</h1>
          <p className="text-muted-foreground">Manage your liquor brands</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Brand
        </motion.button>
      </div>

      {/* Search */}
      <div className="bg-surface rounded-xl p-6 border border-gold/10">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search brands by name or origin..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
          />
        </div>
      </div>

      {/* Brands Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-surface rounded-xl border border-gold/10 overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gold/10">
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Brand Name
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Origin
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Products
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {brands.map((brand, index) => (
                <motion.tr
                  key={brand.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.03 }}
                  className="border-b border-gold/5 hover:bg-surface-elevated transition-colors"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                        <Award className="w-5 h-5 text-gold" />
                      </div>
                      <span className="text-white font-medium">{brand.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{brand.origin}</td>
                  <td className="px-6 py-4 text-white">{brand.products} products</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 text-gold hover:bg-gold/10 rounded-lg transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-wine hover:bg-wine/10 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
