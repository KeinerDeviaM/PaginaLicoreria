import { Outlet, NavLink } from "react-router";
import { motion } from "motion/react";
import {
  LayoutDashboard,
  Package,
  FolderTree,
  Award,
  Truck,
  ArrowRightLeft,
  Bell,
  FileText,
  Search,
  User,
  Wine,
  LogOut,
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Products", href: "/products", icon: Package },
  { name: "Categories", href: "/categories", icon: FolderTree },
  { name: "Brands", href: "/brands", icon: Award },
  { name: "Suppliers", href: "/suppliers", icon: Truck },
  { name: "Inventory", href: "/inventory", icon: ArrowRightLeft },
  { name: "Billing", href: "/billing", icon: FileText },
  { name: "Alerts", href: "/alerts", icon: Bell },
  { name: "Reports", href: "/reports", icon: FileText },
  { name: "Storefront", href: "/shop", icon: Wine },
];

export default function Layout() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="w-64 bg-surface border-r border-gold/10 flex flex-col"
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-gold/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-gold to-wine rounded-lg flex items-center justify-center">
              <Wine className="w-6 h-6 text-black" />
            </div>
            <div>
              <div className="font-semibold text-white">Liquor Store</div>
              <div className="text-xs text-muted-foreground">Inventory Pro</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              end={item.href === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-all group ${
                  isActive
                    ? "bg-gold/10 text-gold"
                    : "text-muted-foreground hover:bg-surface-elevated hover:text-white"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <item.icon className={`w-5 h-5 ${isActive ? "text-gold" : ""}`} />
                  <span className="font-medium">{item.name}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-gold/10">
          <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-surface-elevated">
            <div className="w-8 h-8 bg-gold/20 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-gold" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">Admin User</div>
              <div className="text-xs text-muted-foreground">admin@liquor.com</div>
            </div>
            <button className="text-muted-foreground hover:text-gold transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navbar */}
        <motion.header
          initial={{ y: -64 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="h-16 bg-surface border-b border-gold/10 flex items-center justify-between px-6"
        >
          {/* Search */}
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products, brands, suppliers..."
                className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
              />
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-muted-foreground hover:text-gold transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-wine rounded-full" />
            </button>

            <div className="flex items-center gap-2 pl-4 border-l border-gold/10">
              <div className="w-8 h-8 bg-gradient-to-br from-gold to-wine rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-black" />
              </div>
              <span className="text-sm font-medium text-white">Admin</span>
            </div>
          </div>
        </motion.header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-background p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
