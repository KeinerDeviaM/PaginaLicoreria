import { motion } from "motion/react";
import { Download, Wine, Printer } from "lucide-react";
import { Link } from "react-router";

export default function InvoiceReceipt() {
  return (
    <div className="flex-1 bg-[#f5f5f5] min-h-screen py-12 flex justify-center px-4 font-sans text-black">
      <div className="max-w-4xl w-full">
        <div className="flex justify-end gap-4 mb-6">
          <button className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded text-sm font-bold shadow hover:bg-gray-800 transition-colors">
            <Printer className="w-4 h-4" /> Print
          </button>
          <button className="flex items-center gap-2 bg-gold text-black px-4 py-2 rounded text-sm font-bold shadow hover:bg-yellow-500 transition-colors">
            <Download className="w-4 h-4" /> Download PDF
          </button>
          <Link to="/shop" className="text-sm font-medium text-gray-500 hover:text-black mt-2">Back to store</Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-xl overflow-hidden print:shadow-none"
        >
          {/* Header */}
          <div className="bg-[#0a0a0a] text-white p-12 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-gold to-wine rounded-xl flex items-center justify-center">
                  <Wine className="w-8 h-8 text-black" />
                </div>
                <div>
                  <div className="font-bold text-2xl tracking-tight text-white">LUXE LIQUOR</div>
                  <div className="text-[10px] uppercase tracking-widest text-gold">Premium Spirits</div>
                </div>
              </div>
              <div className="text-white/60 text-sm space-y-1">
                <p>123 Luxury Ave, Suite 100</p>
                <p>New York, NY 10001</p>
                <p>contact@luxeliquor.com</p>
                <p>+1 (555) 123-4567</p>
              </div>
            </div>
            
            <div className="text-right">
              <h1 className="text-4xl font-bold tracking-wider uppercase text-white/20 mb-4">Invoice</h1>
              <div className="space-y-2">
                <div className="flex justify-end gap-6 text-sm">
                  <span className="font-bold text-white/50 uppercase tracking-widest">Invoice No</span>
                  <span className="font-mono text-gold font-bold">INV-2026-8924</span>
                </div>
                <div className="flex justify-end gap-6 text-sm">
                  <span className="font-bold text-white/50 uppercase tracking-widest">Date</span>
                  <span className="font-medium">April 13, 2026</span>
                </div>
                <div className="flex justify-end gap-6 text-sm">
                  <span className="font-bold text-white/50 uppercase tracking-widest">Order No</span>
                  <span className="font-mono font-medium">ORD-2026-8924</span>
                </div>
              </div>
            </div>
          </div>

          {/* Billing Details */}
          <div className="p-12 border-b border-gray-100 flex flex-col md:flex-row justify-between gap-12">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-4">Billed To</h3>
              <div className="text-gray-800 font-medium text-lg mb-1">James Bond</div>
              <div className="text-gray-500 text-sm space-y-1">
                <p>MI6 Headquarters</p>
                <p>85 Albert Embankment</p>
                <p>London SE1 7TP</p>
                <p>United Kingdom</p>
                <p className="mt-2 text-gray-800">james.bond@mi6.gov.uk</p>
              </div>
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-4">Payment Method</h3>
              <div className="flex items-center gap-3 text-gray-800">
                <div className="w-12 h-8 bg-gray-100 border border-gray-200 rounded flex items-center justify-center font-bold text-xs italic">
                  VISA
                </div>
                <div>
                  <div className="font-medium">Credit Card ending in 4242</div>
                  <div className="text-xs text-gray-500">Authorized: April 13, 2026 14:32 EST</div>
                </div>
              </div>
            </div>
          </div>

          {/* Items */}
          <div className="p-12">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b-2 border-black">
                  <th className="py-4 font-bold text-xs uppercase tracking-widest text-gray-500 w-1/2">Description</th>
                  <th className="py-4 font-bold text-xs uppercase tracking-widest text-gray-500 text-center w-1/6">Qty</th>
                  <th className="py-4 font-bold text-xs uppercase tracking-widest text-gray-500 text-right w-1/6">Price</th>
                  <th className="py-4 font-bold text-xs uppercase tracking-widest text-gray-500 text-right w-1/6">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="py-6">
                    <div className="font-bold text-gray-900">Macallan 25 Year Old</div>
                    <div className="text-xs text-gray-500 mt-1">Single Malt Scotch Whisky • 750ml</div>
                    <div className="text-[10px] text-gray-400 font-mono mt-1">SKU: MAC-25Y-001</div>
                  </td>
                  <td className="py-6 text-center font-medium text-gray-700">1</td>
                  <td className="py-6 text-right font-medium text-gray-700">$1,999.00</td>
                  <td className="py-6 text-right font-bold text-gray-900">$1,999.00</td>
                </tr>
                <tr>
                  <td className="py-6">
                    <div className="font-bold text-gray-900">Dom Pérignon Vintage 2012</div>
                    <div className="text-xs text-gray-500 mt-1">Champagne • 750ml</div>
                    <div className="text-[10px] text-gray-400 font-mono mt-1">SKU: DOM-V12-001</div>
                  </td>
                  <td className="py-6 text-center font-medium text-gray-700">2</td>
                  <td className="py-6 text-right font-medium text-gray-700">$249.99</td>
                  <td className="py-6 text-right font-bold text-gray-900">$499.98</td>
                </tr>
              </tbody>
            </table>

            {/* Totals */}
            <div className="mt-8 border-t-2 border-black pt-8 flex justify-end">
              <div className="w-1/2 md:w-1/3 space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="font-bold text-gray-500 uppercase tracking-wider">Subtotal</span>
                  <span className="font-medium text-gray-900">$2,498.98</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-bold text-gray-500 uppercase tracking-wider">Shipping</span>
                  <span className="font-medium text-gray-900">$25.00</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-bold text-gray-500 uppercase tracking-wider">Tax (8%)</span>
                  <span className="font-medium text-gray-900">$199.92</span>
                </div>
                <div className="flex justify-between pt-4 border-t border-gray-200">
                  <span className="font-bold text-gray-900 uppercase tracking-wider text-lg">Total</span>
                  <span className="font-bold text-black text-2xl">$2,723.90</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-gray-50 p-8 text-center text-xs text-gray-500 border-t border-gray-200">
            <p className="font-medium text-gray-800 mb-1">Thank you for your business!</p>
            <p>If you have any questions about this invoice, please contact support at contact@luxeliquor.com or call +1 (555) 123-4567.</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}