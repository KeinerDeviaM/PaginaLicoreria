import { useState } from "react";
import { motion } from "motion/react";
import { Search, Filter, Download, Eye, MoreHorizontal, CheckCircle2, Clock, XCircle } from "lucide-react";

const MOCK_INVOICES = [
  { id: "INV-2026-8924", customer: "James Bond", email: "james.bond@mi6.gov.uk", date: "Apr 13, 2026", amount: 2723.90, status: "paid", items: 3 },
  { id: "INV-2026-8923", customer: "Bruce Wayne", email: "bruce@wayne.ent", date: "Apr 12, 2026", amount: 15450.00, status: "paid", items: 12 },
  { id: "INV-2026-8922", customer: "Tony Stark", email: "t.stark@stark.com", date: "Apr 11, 2026", amount: 8400.50, status: "pending", items: 5 },
  { id: "INV-2026-8921", customer: "Clark Kent", email: "stark@avengers.org", date: "Apr 10, 2026", amount: 450.00, status: "paid", items: 1 },
  { id: "INV-2026-8920", customer: "Arthur Curry", email: "clark@dailyplanet.com", date: "Apr 09, 2026", amount: 120.00, status: "failed", items: 2 },
  { id: "INV-2026-8919", customer: "Diana Prince", email: "diana@themyscira.gov", date: "Apr 08, 2026", amount: 3200.00, status: "paid", items: 4 },
];

export default function Billing() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  const filteredInvoices = MOCK_INVOICES.filter((inv) => {
    const matchesSearch = inv.customer.toLowerCase().includes(searchTerm.toLowerCase()) || inv.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || inv.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-xs font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" /> Paid
          </div>
        );
      case "pending":
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/20 text-xs font-medium">
            <Clock className="w-3.5 h-3.5" /> Pending
          </div>
        );
      case "failed":
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/10 text-red-500 border border-red-500/20 text-xs font-medium">
            <XCircle className="w-3.5 h-3.5" /> Failed
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Billing & Invoices</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage customer orders and payment history.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-surface-elevated border border-gold/10 text-white rounded-lg text-sm font-medium hover:bg-white/5 transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: "Total Revenue", value: "$124,500.00", trend: "+12.5%" },
          { label: "Pending Payments", value: "$8,400.50", trend: "3 invoices" },
          { label: "Successful Orders", value: "842", trend: "+5.2%" },
        ].map((kpi, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-surface rounded-2xl border border-gold/10 p-6 flex flex-col justify-between"
          >
            <div className="text-sm font-medium text-muted-foreground mb-2">{kpi.label}</div>
            <div className="text-3xl font-bold text-white mb-2">{kpi.value}</div>
            <div className="text-xs font-medium text-emerald-400">{kpi.trend} this month</div>
          </motion.div>
        ))}
      </div>

      {/* Main Content */}
      <div className="bg-surface rounded-2xl border border-gold/10 overflow-hidden flex flex-col">
        {/* Toolbar */}
        <div className="p-4 border-b border-gold/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-elevated/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by invoice ID or customer..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-gold/30 focus:ring-1 focus:ring-gold/30 transition-all"
            />
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="pl-10 pr-8 py-2 bg-surface-elevated border border-gold/10 rounded-lg text-sm text-white focus:outline-none focus:border-gold/30 focus:ring-1 focus:ring-gold/30 transition-all appearance-none cursor-pointer"
              >
                <option value="all">All Statuses</option>
                <option value="paid">Paid</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
              </select>
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-gold/10 bg-surface-elevated/30">
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-[150px]">Invoice ID</th>
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Customer</th>
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Date</th>
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-right">Amount</th>
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-center">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider text-right w-[100px]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gold/10">
              {filteredInvoices.map((invoice, idx) => (
                <motion.tr
                  key={invoice.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="hover:bg-surface-elevated/50 transition-colors group"
                >
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-white group-hover:text-gold transition-colors">{invoice.id}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-white">{invoice.customer}</div>
                    <div className="text-xs text-muted-foreground">{invoice.email}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">
                    {invoice.date}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-white text-right">
                    ${invoice.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    <div className="text-xs text-muted-foreground font-normal">{invoice.items} items</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    {getStatusBadge(invoice.status)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 text-muted-foreground hover:text-gold hover:bg-gold/10 rounded-lg transition-colors" title="View details">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-muted-foreground hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
              
              {filteredInvoices.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                    No invoices found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-4 border-t border-gold/10 flex items-center justify-between text-sm text-muted-foreground bg-surface-elevated/50">
          <div>Showing 1 to {filteredInvoices.length} of {filteredInvoices.length} entries</div>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-gold/10 rounded hover:bg-white/5 disabled:opacity-50" disabled>Previous</button>
            <button className="px-3 py-1 border border-gold/10 rounded hover:bg-white/5 disabled:opacity-50" disabled>Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}