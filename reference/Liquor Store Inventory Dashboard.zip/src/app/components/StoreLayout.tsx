import { Outlet, Link, NavLink } from "react-router";
import { motion } from "motion/react";
import { Wine, ShoppingCart, Search, User, Menu } from "lucide-react";

export default function StoreLayout() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col font-sans">
      {/* Top Banner */}
      <div className="bg-wine py-2 text-center text-xs font-medium tracking-wide">
        Free delivery on orders over $150 | Premium selection guaranteed
      </div>

      {/* Navigation */}
      <header className="sticky top-0 z-50 bg-[#121212]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          {/* Logo */}
          <Link to="/shop" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-gradient-to-br from-gold to-wine rounded-xl flex items-center justify-center transition-transform group-hover:scale-105">
              <Wine className="w-6 h-6 text-black" />
            </div>
            <div>
              <div className="font-bold text-lg tracking-tight text-white group-hover:text-gold transition-colors">
                LUXE LIQUOR
              </div>
              <div className="text-[10px] uppercase tracking-widest text-white/50">
                Est. 2025
              </div>
            </div>
          </Link>

          {/* Main Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <NavLink
              to="/shop"
              end
              className={({ isActive }) =>
                `text-sm font-medium tracking-wide uppercase transition-colors ${
                  isActive ? "text-gold" : "text-white/70 hover:text-white"
                }`
              }
            >
              Discover
            </NavLink>
            <NavLink
              to="/shop/products"
              className={({ isActive }) =>
                `text-sm font-medium tracking-wide uppercase transition-colors ${
                  isActive ? "text-gold" : "text-white/70 hover:text-white"
                }`
              }
            >
              Spirits & Wine
            </NavLink>
            <a
              href="#"
              className="text-sm font-medium tracking-wide uppercase text-white/70 hover:text-white transition-colors"
            >
              Collections
            </a>
            <a
              href="#"
              className="text-sm font-medium tracking-wide uppercase text-white/70 hover:text-white transition-colors"
            >
              Gifting
            </a>
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-6">
            <button className="text-white/70 hover:text-gold transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <Link to="/login" className="text-white/70 hover:text-gold transition-colors hidden md:block">
              <User className="w-5 h-5" />
            </Link>
            <Link to="/shop/cart" className="relative text-white/70 hover:text-gold transition-colors">
              <ShoppingCart className="w-5 h-5" />
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-gold text-black text-[10px] font-bold rounded-full flex items-center justify-center">
                2
              </span>
            </Link>
            <button className="md:hidden text-white/70 hover:text-gold transition-colors">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#121212] border-t border-white/5 py-16 mt-20">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-gold to-wine rounded-lg flex items-center justify-center">
                <Wine className="w-5 h-5 text-black" />
              </div>
              <div className="font-bold text-lg tracking-tight text-white">
                LUXE LIQUOR
              </div>
            </div>
            <p className="text-sm text-white/50 leading-relaxed">
              Curating the world's finest spirits, wines, and champagnes for the discerning palate. Experience luxury in every drop.
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-6">Shop</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Rare Spirits</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Fine Wines</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Champagne</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">New Arrivals</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-6">Support</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">Returns</a></li>
              <li><a href="#" className="text-sm text-white/50 hover:text-gold transition-colors">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-6">Newsletter</h4>
            <p className="text-sm text-white/50 mb-4">Subscribe for exclusive releases and private tasting events.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Email Address" 
                className="bg-[#1a1a1a] border border-white/10 rounded-l-lg px-4 py-2 w-full text-sm text-white focus:outline-none focus:border-gold"
              />
              <button className="bg-gold text-black px-4 py-2 text-sm font-bold rounded-r-lg hover:bg-gold/90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between">
          <p className="text-xs text-white/40">© 2026 Luxe Liquor. All rights reserved.</p>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <Link to="/" className="text-xs text-white/40 hover:text-gold transition-colors">Admin Dashboard</Link>
            <span className="text-white/20">|</span>
            <a href="#" className="text-xs text-white/40 hover:text-gold transition-colors">Privacy</a>
            <span className="text-white/20">|</span>
            <a href="#" className="text-xs text-white/40 hover:text-gold transition-colors">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}