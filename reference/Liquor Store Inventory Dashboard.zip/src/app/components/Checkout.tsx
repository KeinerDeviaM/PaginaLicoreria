import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "motion/react";
import { Check, ChevronRight, Truck, Store, CreditCard, Banknote, Building, CheckCircle2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function Checkout() {
  const [step, setStep] = useState(1);
  const [deliveryMethod, setDeliveryMethod] = useState("delivery");
  const [paymentMethod, setPaymentMethod] = useState("card");
  const navigate = useNavigate();

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
    else navigate("/shop/success");
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const cartTotal = 2498.99 + 25.0 + 199.92; // Placeholder

  return (
    <div className="flex-1 bg-[#0a0a0a] min-h-screen">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold tracking-tight text-white mb-8">Checkout</h1>

        {/* Stepper */}
        <div className="flex items-center gap-2 mb-12 overflow-x-auto pb-4">
          {[
            { id: 1, label: "Customer Info" },
            { id: 2, label: "Delivery" },
            { id: 3, label: "Payment" },
            { id: 4, label: "Review" },
          ].map((s, i) => (
            <div key={s.id} className="flex items-center gap-2 shrink-0">
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold border transition-colors ${
                  step === s.id
                    ? "bg-gold border-gold text-black"
                    : step > s.id
                    ? "bg-white/10 border-transparent text-white"
                    : "bg-[#1a1a1a] border-white/10 text-white/40"
                }`}
              >
                {step > s.id ? <Check className="w-4 h-4" /> : s.id}
              </div>
              <span
                className={`text-sm font-medium uppercase tracking-wider ${
                  step === s.id ? "text-gold" : step > s.id ? "text-white" : "text-white/40"
                }`}
              >
                {s.label}
              </span>
              {i < 3 && <div className="w-12 h-[1px] bg-white/10 mx-2" />}
            </div>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Content */}
          <div className="flex-1">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-[#121212] border border-white/5 rounded-2xl p-8"
            >
              {step === 1 && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Customer Information</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-white/70 mb-2">First Name</label>
                      <input
                        type="text"
                        placeholder="James"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white/70 mb-2">Last Name</label>
                      <input
                        type="text"
                        placeholder="Bond"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-white/70 mb-2">Email Address</label>
                      <input
                        type="email"
                        placeholder="james.bond@mi6.gov"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-white/70 mb-2">Phone Number</label>
                      <input
                        type="tel"
                        placeholder="+44 7700 900077"
                        className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Delivery Method</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                    <label
                      className={`relative flex items-center p-4 border rounded-xl cursor-pointer transition-colors ${
                        deliveryMethod === "delivery"
                          ? "border-gold bg-gold/5"
                          : "border-white/10 bg-[#1a1a1a] hover:border-white/30"
                      }`}
                    >
                      <input
                        type="radio"
                        name="delivery"
                        value="delivery"
                        checked={deliveryMethod === "delivery"}
                        onChange={(e) => setDeliveryMethod(e.target.value)}
                        className="sr-only"
                      />
                      <div className="flex-1 flex gap-4">
                        <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                          <Truck className="w-5 h-5 text-gold" />
                        </div>
                        <div>
                          <h3 className="text-base font-bold text-white mb-1">Standard Delivery</h3>
                          <p className="text-sm text-white/50">2-3 business days</p>
                          <p className="text-sm font-bold text-gold mt-1">$25.00</p>
                        </div>
                      </div>
                      {deliveryMethod === "delivery" && <CheckCircle2 className="w-5 h-5 text-gold absolute top-4 right-4" />}
                    </label>

                    <label
                      className={`relative flex items-center p-4 border rounded-xl cursor-pointer transition-colors ${
                        deliveryMethod === "pickup"
                          ? "border-gold bg-gold/5"
                          : "border-white/10 bg-[#1a1a1a] hover:border-white/30"
                      }`}
                    >
                      <input
                        type="radio"
                        name="delivery"
                        value="pickup"
                        checked={deliveryMethod === "pickup"}
                        onChange={(e) => setDeliveryMethod(e.target.value)}
                        className="sr-only"
                      />
                      <div className="flex-1 flex gap-4">
                        <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                          <Store className="w-5 h-5 text-gold" />
                        </div>
                        <div>
                          <h3 className="text-base font-bold text-white mb-1">Store Pickup</h3>
                          <p className="text-sm text-white/50">Available in 2 hours</p>
                          <p className="text-sm font-bold text-emerald-400 mt-1">Free</p>
                        </div>
                      </div>
                      {deliveryMethod === "pickup" && <CheckCircle2 className="w-5 h-5 text-gold absolute top-4 right-4" />}
                    </label>
                  </div>

                  {deliveryMethod === "delivery" && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-white/10">
                      <div className="sm:col-span-2">
                        <label className="block text-sm font-medium text-white/70 mb-2">Street Address</label>
                        <input
                          type="text"
                          placeholder="123 Luxury Lane"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white/70 mb-2">City</label>
                        <input
                          type="text"
                          placeholder="New York"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white/70 mb-2">ZIP Code</label>
                        <input
                          type="text"
                          placeholder="10001"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {step === 3 && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Payment Method</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                    {[
                      { id: "card", label: "Credit Card", icon: CreditCard },
                      { id: "transfer", label: "Bank Transfer", icon: Building },
                      { id: "cash", label: "Cash on Delivery", icon: Banknote },
                    ].map((method) => (
                      <label
                        key={method.id}
                        className={`relative flex flex-col items-center justify-center p-6 border rounded-xl cursor-pointer transition-colors text-center ${
                          paymentMethod === method.id
                            ? "border-gold bg-gold/5"
                            : "border-white/10 bg-[#1a1a1a] hover:border-white/30"
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment"
                          value={method.id}
                          checked={paymentMethod === method.id}
                          onChange={(e) => setPaymentMethod(e.target.value)}
                          className="sr-only"
                        />
                        <method.icon className={`w-8 h-8 mb-3 ${paymentMethod === method.id ? "text-gold" : "text-white/40"}`} />
                        <span className="text-sm font-bold text-white">{method.label}</span>
                        {paymentMethod === method.id && <CheckCircle2 className="w-4 h-4 text-gold absolute top-3 right-3" />}
                      </label>
                    ))}
                  </div>

                  {paymentMethod === "card" && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-white/10">
                      <div className="sm:col-span-2">
                        <label className="block text-sm font-medium text-white/70 mb-2">Card Number</label>
                        <input
                          type="text"
                          placeholder="0000 0000 0000 0000"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white font-mono tracking-widest focus:outline-none focus:border-gold"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white/70 mb-2">Expiry Date</label>
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white/70 mb-2">CVC</label>
                        <input
                          type="text"
                          placeholder="123"
                          className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {step === 4 && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Review Order</h2>
                  <div className="space-y-6 mb-8">
                    {/* Item Review */}
                    <div className="flex items-center gap-4 bg-[#1a1a1a] p-4 rounded-xl border border-white/5">
                      <div className="w-16 h-20 bg-black rounded p-2 flex items-center justify-center shrink-0">
                        <ImageWithFallback src="https://images.unsplash.com/photo-1762983039830-9606927656da?w=200" alt="Macallan" className="w-full h-full object-contain" />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs font-bold text-gold uppercase mb-1">The Macallan</div>
                        <h4 className="text-white font-bold line-clamp-1">Macallan 25 Year Old</h4>
                        <p className="text-sm text-white/50">Qty: 1</p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-white">$1,999.00</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-white/10">
                      <div>
                        <h4 className="text-sm font-bold uppercase tracking-wider text-white/40 mb-3">Delivery Information</h4>
                        <p className="text-sm text-white font-medium mb-1">Standard Delivery</p>
                        <p className="text-sm text-white/60">James Bond</p>
                        <p className="text-sm text-white/60">123 Luxury Lane</p>
                        <p className="text-sm text-white/60">New York, 10001</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-bold uppercase tracking-wider text-white/40 mb-3">Payment Method</h4>
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-white/60" />
                          <span className="text-sm text-white font-medium">Card ending in 4242</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-between items-center mt-10 pt-6 border-t border-white/10">
                <button
                  onClick={handleBack}
                  className={`px-6 py-3 text-sm font-bold uppercase tracking-wider text-white/60 hover:text-white transition-colors ${
                    step === 1 ? "invisible" : ""
                  }`}
                >
                  Back
                </button>
                <button
                  onClick={handleNext}
                  className="px-8 py-4 bg-gold text-black font-bold uppercase tracking-wider text-sm rounded hover:bg-white transition-colors flex items-center gap-2"
                >
                  {step === 4 ? "Complete Order" : "Continue"} <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="w-full lg:w-96 shrink-0">
            <div className="bg-[#121212] border border-white/5 rounded-2xl p-8 sticky top-28">
              <h2 className="text-xl font-bold text-white mb-6">Order Summary</h2>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm">
                  <span className="text-white/60">Subtotal</span>
                  <span className="text-white font-medium">$2,498.99</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/60">Shipping</span>
                  <span className="text-white font-medium">{deliveryMethod === "delivery" ? "$25.00" : "Free"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/60">Tax (8%)</span>
                  <span className="text-white font-medium">$199.92</span>
                </div>
              </div>

              <div className="border-t border-white/10 pt-6">
                <div className="flex justify-between items-end">
                  <span className="text-base font-bold text-white">Total</span>
                  <span className="text-3xl font-bold text-gold">
                    ${(cartTotal - (deliveryMethod === "pickup" ? 25 : 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}