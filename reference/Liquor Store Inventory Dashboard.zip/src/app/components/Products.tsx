import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Search, Plus, Edit2, Trash2, Filter, Download } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Jack Daniel's No. 7",
    category: "Whiskey",
    brand: "Jack Daniel's",
    price: 28.99,
    stock: 145,
    status: "In Stock",
  },
  {
    id: 2,
    name: "Château Margaux 2015",
    category: "Wine",
    brand: "Château Margaux",
    price: 899.0,
    stock: 8,
    status: "Low Stock",
  },
  {
    id: 3,
    name: "Grey Goose Vodka",
    category: "Vodka",
    brand: "Grey Goose",
    price: 39.99,
    stock: 8,
    status: "Low Stock",
  },
  {
    id: 4,
    name: "Macallan 18 Year",
    category: "Whiskey",
    brand: "Macallan",
    price: 349.0,
    stock: 12,
    status: "In Stock",
  },
  {
    id: 5,
    name: "Patrón Silver Tequila",
    category: "Tequila",
    brand: "Patrón",
    price: 54.99,
    stock: 67,
    status: "In Stock",
  },
  {
    id: 6,
    name: "Moët & Chandon Brut",
    category: "Champagne",
    brand: "Moët & Chandon",
    price: 54.99,
    stock: 34,
    status: "In Stock",
  },
  {
    id: 7,
    name: "Johnnie Walker Blue",
    category: "Whiskey",
    brand: "Johnnie Walker",
    price: 229.99,
    stock: 0,
    status: "Out of Stock",
  },
  {
    id: 8,
    name: "Hennessy V.S",
    category: "Cognac",
    brand: "Hennessy",
    price: 49.99,
    stock: 89,
    status: "In Stock",
  },
];

export default function Products() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Products</h1>
          <p className="text-muted-foreground">Manage your liquor inventory</p>
        </div>
        <Link to="/products/new">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
          >
            <Plus className="w-5 h-5" />
            Add Product
          </motion.button>
        </Link>
      </div>

      {/* Filters and Search */}
      <div className="bg-surface rounded-xl p-6 border border-gold/10">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search products by name, brand, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-surface-elevated border border-gold/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder:text-muted-foreground focus:border-gold/30 focus:outline-none focus:ring-2 focus:ring-gold/20 transition-all"
            />
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 bg-surface-elevated border border-gold/10 px-4 py-3 rounded-lg text-white hover:border-gold/30 transition-all">
              <Filter className="w-5 h-5" />
              Filter
            </button>
            <button className="flex items-center gap-2 bg-surface-elevated border border-gold/10 px-4 py-3 rounded-lg text-white hover:border-gold/30 transition-all">
              <Download className="w-5 h-5" />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-surface rounded-xl border border-gold/10 overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gold/10">
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Product Name
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Category
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Brand
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Price
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Stock
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Status
                </th>
                <th className="text-left px-6 py-4 text-sm font-semibold text-muted-foreground">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <motion.tr
                  key={product.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-gold/5 hover:bg-surface-elevated transition-colors"
                >
                  <td className="px-6 py-4 text-white font-medium">{product.name}</td>
                  <td className="px-6 py-4 text-muted-foreground">{product.category}</td>
                  <td className="px-6 py-4 text-muted-foreground">{product.brand}</td>
                  <td className="px-6 py-4 text-white font-medium">
                    ${product.price.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-white">{product.stock}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        product.status === "In Stock"
                          ? "bg-green-500/10 text-green-500"
                          : product.status === "Low Stock"
                          ? "bg-yellow-500/10 text-yellow-500"
                          : "bg-red-500/10 text-red-500"
                      }`}
                    >
                      {product.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Link to={`/products/${product.id}/edit`} className="p-2 text-gold hover:bg-gold/10 rounded-lg transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </Link>
                      <button className="p-2 text-wine hover:bg-wine/10 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
