import { motion } from "motion/react";
import { Plus, Edit2, Trash2, Package } from "lucide-react";

const categories = [
  { id: 1, name: "Whiskey", products: 320, color: "gold" },
  { id: 2, name: "Wine", products: 280, color: "wine" },
  { id: 3, name: "Vodka", products: 250, color: "gold" },
  { id: 4, name: "Rum", products: 180, color: "wine" },
  { id: 5, name: "Tequila", products: 140, color: "gold" },
  { id: 6, name: "Cognac", products: 95, color: "wine" },
  { id: 7, name: "Gin", products: 87, color: "gold" },
  { id: 8, name: "Champagne", products: 78, color: "wine" },
  { id: 9, name: "Liqueur", products: 65, color: "gold" },
  { id: 10, name: "Brandy", products: 43, color: "wine" },
];

export default function Categories() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Categories</h1>
          <p className="text-muted-foreground">Organize your product categories</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-gradient-to-r from-gold to-[#C19A6B] text-black px-6 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-gold/20 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Category
        </motion.button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {categories.map((category, index) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-surface rounded-xl p-6 border border-gold/10 hover:border-gold/20 transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <div
                className={`w-14 h-14 rounded-lg flex items-center justify-center ${
                  category.color === "gold"
                    ? "bg-gold/10 text-gold"
                    : "bg-wine/10 text-wine"
                }`}
              >
                <Package className="w-7 h-7" />
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 text-gold hover:bg-gold/10 rounded-lg transition-colors">
                  <Edit2 className="w-4 h-4" />
                </button>
                <button className="p-2 text-wine hover:bg-wine/10 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">{category.name}</h3>
            <p className="text-muted-foreground">{category.products} products</p>
          </motion.div>
        ))}
      </div>

      {/* Stats Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-surface rounded-xl p-6 border border-gold/10"
      >
        <h2 className="text-xl font-semibold text-white mb-4">Category Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="text-3xl font-semibold text-white mb-1">
              {categories.length}
            </div>
            <div className="text-sm text-muted-foreground">Total Categories</div>
          </div>
          <div>
            <div className="text-3xl font-semibold text-white mb-1">
              {categories.reduce((acc, cat) => acc + cat.products, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Products</div>
          </div>
          <div>
            <div className="text-3xl font-semibold text-white mb-1">
              {Math.round(
                categories.reduce((acc, cat) => acc + cat.products, 0) / categories.length
              )}
            </div>
            <div className="text-sm text-muted-foreground">Average per Category</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
