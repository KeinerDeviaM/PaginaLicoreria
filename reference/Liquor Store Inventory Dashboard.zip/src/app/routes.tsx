import { createBrowserRouter } from "react-router";
import Layout from "./components/Layout";
import Login from "./components/Login";
import Register from "./components/Register";
import ForgotPassword from "./components/ForgotPassword";
import Dashboard from "./components/Dashboard";
import Products from "./components/Products";
import AddEditProduct from "./components/AddEditProduct";
import Categories from "./components/Categories";
import Brands from "./components/Brands";
import Suppliers from "./components/Suppliers";
import Inventory from "./components/Inventory";
import Alerts from "./components/Alerts";
import Reports from "./components/Reports";
import Billing from "./components/Billing";

import StoreLayout from "./components/StoreLayout";
import StoreHome from "./components/StoreHome";
import ProductCatalog from "./components/ProductCatalog";
import ProductDetails from "./components/ProductDetails";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout";
import PurchaseSuccess from "./components/PurchaseSuccess";
import InvoiceReceipt from "./components/InvoiceReceipt";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/register",
    Component: Register,
  },
  {
    path: "/forgot-password",
    Component: ForgotPassword,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "products", Component: Products },
      { path: "products/new", Component: AddEditProduct },
      { path: "products/:id/edit", Component: AddEditProduct },
      { path: "categories", Component: Categories },
      { path: "brands", Component: Brands },
      { path: "suppliers", Component: Suppliers },
      { path: "inventory", Component: Inventory },
      { path: "alerts", Component: Alerts },
      { path: "reports", Component: Reports },
      { path: "billing", Component: Billing },
    ],
  },
  {
    path: "/shop",
    Component: StoreLayout,
    children: [
      { index: true, Component: StoreHome },
      { path: "products", Component: ProductCatalog },
      { path: "products/:id", Component: ProductDetails },
      { path: "cart", Component: Cart },
      { path: "checkout", Component: Checkout },
      { path: "success", Component: PurchaseSuccess },
      { path: "receipt", Component: InvoiceReceipt },
    ],
  },
]);
